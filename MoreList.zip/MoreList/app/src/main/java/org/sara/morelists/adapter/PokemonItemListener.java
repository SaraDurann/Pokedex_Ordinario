package org.sara.morelists.adapter;

public interface PokemonItemListener {
    void onPokemonClicked(int position);
}
